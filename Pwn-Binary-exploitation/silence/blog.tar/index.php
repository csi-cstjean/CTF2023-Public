<!DOCTYPE html>
<html>
<head>
    <title>Journal d'Eric Arcand</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<header class="header-content">
    <h1>Journal d'Eric Arcand</h1>
    <nav>
        <ul>
            <li><a href="index.php">Accueil</a></li>
        </ul>
    </nav>
</header>

<section class="banner">
    <h2>Bienvenue à l'épicentre de la vérité!</h2>
    <p>Découvrez les faits sur la société secrète du Cégep de Saint-Jean-sur-Richelieu.</p>
</section>

<section class="main">
    <h2>Derniers Articles</h2>
    <div class="article">
        <h3><a href="immortalite.php">Immortalité - Réservée aux Élites?</a></h3>
        <p>Cette société aurait percée les secrets de l'immortalité.</p>
    </div>
    <div class="article">
        <h3><a href="societe.php">Société secrète à Saint-Jean-sur-Richelieu?</a></h3>
        <p>Une société secrète cachée parmis les ténèbres du Cégep Saint-Jean-sur-Richelieu.</p>
    </div>
</section>

<section class="contact-info">
    <h2>Contact</h2>
    <p>N'hésitez pas à me contacter pour partager des informations, poser des questions ou discuter de vos
        découvertes.</p>
    <p>Email : <a href="mailto:contact@investigateurjournal.com">e.arcand@proton.me</a></p>
</section>

<footer>
    <p>&copy; 2023 Journal d'Eric Arcand</p>
</footer>
</body>
</html>
