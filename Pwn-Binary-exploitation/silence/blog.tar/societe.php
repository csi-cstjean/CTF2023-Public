<!DOCTYPE html>
<html>
<head>
    <title>Société secrète à Saint-Jean-sur-Richelieu?</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<header class="header-content">
    <h1>Société secrète à Saint-Jean-sur-Richelieu?</h1>
    <nav>
        <ul>
            <li><a href="index.php">Accueil</a></li>
        </ul>
    </nav>
</header>

<section class="main">
    <p><em>Par Eric Arcand</em></p>
    <p><em>Date : 7 Octobre 2023</em></p>
    <br/>
    <p>Cher lecteur, je crois avoir tombé sur une révélation qui va faire trembler le Québec entier</p>
    <p>Vous avez probablement lu le titre. << Une société secrète, à Saint-Jean-sur-Richelieu? Dans un établissement officiel du gouvernement? >> </p>
    <p>C'est surprenant n'est-ce pas? Comment est-ce que c'est possible?</p>
    <p>Croyez-moi, avant cette semaine, j'étais moi aussi une petite brebis innocente, totalement inconscient des sombres secrets cachés dans ce Cégep.</p>
    <br/>
    <h2>La découverte du siècle</h2>
    <p>Comment ai-je fait pour découvrir ce sombre secret?. Ça l'a été d'une simplicité assez absurde!</p>
    <p>Vous voyez, je prenais une petite marche dans le coin et, en regardant en direction du Cégep, j'ai apperçu un groupe de gens extrêmement louche.</p>
    <p>Imaginez: Un groupe de jeune avec des hoodies avec la lettre "n" et un espèce de cadenas ouvert étrange? J'étais trop loin pour bien voir, mais j'en ai vu assez pour que ça l'attire mon attention!</p>
    <p>J'ai tenté d'appeler la direction sur le champ! Aucune réponse. Le silence le plus total!</p>
    <p>Après avoir observé où ces élèves se dirigeaient, j'ai tenté de repérer dans quel local ils allaient se cacher. Heureusement pour moi, leur destination finale êtait près de la fenêtre!</p>
    <p>Ils semblaient avoir rentré dans un cour d'informatique? Enfin bref, malgré mes doutes sur la légétimité de cette rencontre, j'ai seulement prit une image mentale du professeur et je suis parti quelques heures le temps que le << cour >> se termine.</p>
    <p>Après coup, j'ai tenté de parler à leur << professeur >> (un certain St-Hilaire? Les détails m'échappent) et vous ne croirai pas la réponse qu'il m'a donné.</p>
    <br/>
    <p><< Ah ça? C'est un hoodie de compétition >></p>
    <br/>
    <p>Donc on récapitule, un groupe de jeune avec des accoutrements étranges qui se rassemblent annuellement pour participer à une << compétition >>?</p>
    <p>Ça sonne comme un cover-up parfait, vous ne trouvez pas? Un merveilleux prétexte pour dissimuler les réelles raisons de ces rencontres.</p>
    <p>Il y en a plus à cette histoire, j'en suis certain!</p>
    <p>Et je ne me reposerai jamais jusqu'à temps que ce mystère soit dévoilée à la lumière du jour!</p>
    <br/>
</section>

<footer>
    <p>&copy; 2023 Journal d'Eric Arcand</p>
</footer>
</body>
</html>
