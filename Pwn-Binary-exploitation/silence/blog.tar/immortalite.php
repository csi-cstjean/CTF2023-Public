<!DOCTYPE html>
<html>
<head>
    <title>L'Immortalité des Élites : Une Idée Insolite</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<header class="header-content">
    <h1>Immortalité - Réservée aux Élites?</h1>
    <nav>
        <ul>
            <li><a href="index.php">Accueil</a></li>
        </ul>
    </nav>
</header>

<section class="main">
    <p><em>Par Eric Arcand</em></p>
    <p><em>Date : 15 Octobre 2023</em></p>
    <br/>
    <p>Cher lecteur, j'espère que vous êtes attaché à votre siège. Cette histoire va vous faire grimper dans les
        rideaux</p>
    <p>Je ne veux pas révéler mes sources afin de ne pas risquer leur vie, mais je vous jure tout ce qui est ci-dessous
        est vrai.</p>
    <br/>
    <p>Dites-moi, cher lecteur, si vous étiez à la tête d'une des plus grandes sociétés secrètes avec comme confrères
        les plus grand génies de ce monde. Est-ce que vous ne feriez pas tout afin de garder ces derniers en vie?</p>
    <p>Un génie qui non seulement sait garder le secret, mais avec des valeurs alignées avec les votres? C'est rare,
        voire introuvable.</p>
    <p>Ne seriez-vous pas prêt à tout afin de les garder en vie?</p>
    <p>Même à briser l'essence même de l'être humain?</p>
    <br/>
    <h2>La solution: Percer les secrets de l'immortalité</h2>
    <p>Ne serait-il pas possible que cette société créée par les plus grands génies de ce monde aient réussi à vaincre
        la mortalité?</p>
    <p>Même vous et moi, nous sommes capables de trouver des possibilités! On a simplement qu'à téléverser notre conscience
        dans le cloud et le tour est joué!</p>
    <p>Nous pourrions aussi délester notre chair et devenir des machines!</p>
    <p>Mais pourtant, les scientifiques les plus brillants du monde qui supposément travaillent corps et âme à mettre
        fin à la
        mortalité depuis des siècles, voire des MILLÉNAIRES, sont incapables d'amener une théorie? Même pas une
        piste?</p>
    <p>Bien sur que non! Vous voyez, cher lecteur, ne nous sommes pas assez importants pour devenir immortel! Ces élites
        préfèrent de loin garder ce secret pour eux et bénéficier de l'immortalité, à l'abris de toutes conséquences et
        principes éthiques</p>
    <p>Certains de leurs chercheurs ont tentés de nous révélez ce secret, mais ils n'ont, jusqu'à maintenant, toujours
        été forcé au silence par le système</p>
    <br/>
    <h3>Ce secret fini aujourd'hui</h3>
    <p>Tant et aussi longtemps que je suis en vie, je, Eric Arcand, vais être l'agent de vérité. Je travaillerai sans
        relâche jusqu'à temps que tous les secrets de cette société soient révélés à la lumière du jour!</p>
    <br/>
</section>

<footer>
    <p>&copy; 2023 Journal d'Eric Arcand</p>
</footer>
</body>
</html>
